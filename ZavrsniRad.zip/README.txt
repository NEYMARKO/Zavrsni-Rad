FER LaTeX predložak - brzi start
================================

"Brzi start" sadrži izgrađenu strukturu za pisanje
radova koristeći razvijeni LaTeX predložak.

Odaberite datoteke specifične za tip vašeg rada te
datoteku "literatura.bib" i spremni ste za pisanje.

Primjerice, za Završni rad, potrebne su datoteke:
- zavrsni.tex
- fer.cls
- fer.bst
- literatura.bib
